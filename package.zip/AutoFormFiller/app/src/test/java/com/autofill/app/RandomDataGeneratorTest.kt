package com.autofill.app

import org.junit.Test
import org.junit.Assert.*
import com.autofill.app.data.generator.RandomDataGenerator

/**
 * RandomDataGenerator için birim testleri.
 * Random veri üretim fonksiyonlarını test eder.
 */
class RandomDataGeneratorTest {

    private val generator = RandomDataGenerator()

    @Test
    fun `getRandomName returns non-empty name`() {
        val name = generator.getRandomName()
        assertTrue("İsim boş olmamalı", name.isNotBlank())
        assertTrue("İsim space içermeli", name.contains(" "))
    }

    @Test
    fun `getRandomFirstName returns valid Turkish name`() {
        val firstName = generator.getRandomFirstName()
        assertTrue("İsim boş olmamalı", firstName.isNotBlank())
        assertTrue("İsim harf içermeli", firstName.all { it.isLetter() })
    }

    @Test
    fun `getRandomLastName returns valid Turkish surname`() {
        val lastName = generator.getRandomLastName()
        assertTrue("Soyisim boş olmamalı", lastName.isNotBlank())
    }

    @Test
    fun `getRandomEmail returns valid email format`() {
        val email = generator.getRandomEmail()
        assertTrue("Email boş olmamalı", email.isNotBlank())
        assertTrue("Email @ içermeli", email.contains("@"))
        assertTrue("Email domain içermeli", email.contains("."))
    }

    @Test
    fun `getRandomPhone returns valid Turkish phone format`() {
        val phone = generator.getRandomPhone()
        assertTrue("Telefon boş olmamalı", phone.isNotBlank())
        assertTrue("Telefon +90 içermeli", phone.contains("+90"))
    }

    @Test
    fun `getRandomAddress returns non-empty address`() {
        val address = generator.getRandomAddress()
        assertTrue("Adres boş olmamalı", address.isNotBlank())
        assertTrue("Adres Mah. içermeli", address.contains("Mah."))
    }

    @Test
    fun `getRandomCity returns valid city`() {
        val city = generator.getRandomCity()
        assertTrue("Şehir boş olmamalı", city.isNotBlank())
    }

    @Test
    fun `getRandomCountry returns valid country`() {
        val country = generator.getRandomCountry()
        assertTrue("Ülke boş olmamalı", country.isNotBlank())
    }

    @Test
    fun `getRandomDate returns valid date format`() {
        val date = generator.getRandomDate()
        assertTrue("Tarih boş olmamalı", date.isNotBlank())
        assertTrue("Tarih nokta içermeli", date.contains("."))
    }

    @Test
    fun `getRandomNumber returns number in range`() {
        val min = 10
        val max = 50
        val number = generator.getRandomNumber(min, max).toInt()
        assertTrue("Sayı $min ve $max arasında olmalı", number in min..max)
    }

    @Test
    fun `getRandomText returns non-empty text`() {
        val text = generator.getRandomText(5)
        assertTrue("Metin boş olmamalı", text.isNotBlank())
        assertTrue("Metin kelime içermeli", text.contains(" "))
    }

    @Test
    fun `getRandomRating returns number between 1 and 5`() {
        val rating = generator.getRandomRating().toInt()
        assertTrue("Derecelendirme 1-5 arasında olmalı", rating in 1..5)
    }

    @Test
    fun `getRandomYesNo returns either Evet or Hayır`() {
        val yesNo = generator.getRandomYesNo()
        assertTrue("Değer Evet veya Hayır olmalı", yesNo == "Evet" || yesNo == "Hayır")
    }

    @Test
    fun `getValueForFieldType with email type returns email`() {
        val email = generator.getValueForFieldType("email", "")
        assertTrue("Email tipi için email döndürmeli", email.contains("@"))
    }

    @Test
    fun `getValueForFieldType with phone label returns phone`() {
        val phone = generator.getValueForFieldType("text", "Telefon numaranız")
        assertTrue("Telefon label'ı için telefon döndürmeli", phone.contains("+90"))
    }

    @Test
    fun `getValueForFieldType with number type returns number`() {
        val number = generator.getValueForFieldType("number", "")
        assertTrue("Number tipi için sayı döndürmeli", number.all { it.isDigit() })
    }

    @Test
    fun `generateAllData returns complete RandomData object`() {
        val data = generator.generateAllData()
        assertTrue("İsim dolu olmalı", data.firstName.isNotBlank())
        assertTrue("Soyisim dolu olmalı", data.lastName.isNotBlank())
        assertTrue("Email dolu olmalı", data.email.isNotBlank())
        assertTrue("Telefon dolu olmalı", data.phone.isNotBlank())
        assertTrue("Adres dolu olmalı", data.address.isNotBlank())
        assertTrue("Şehir dolu olmalı", data.city.isNotBlank())
        assertTrue("Ülke dolu olmalı", data.country.isNotBlank())
    }

    @Test
    fun `multiple calls to random functions return varied results`() {
        val emails = (1..10).map { generator.getRandomEmail() }.toSet()
        assertTrue("10 çağrıda en az 5 farklı email olmalı", emails.size >= 5)
    }
}
