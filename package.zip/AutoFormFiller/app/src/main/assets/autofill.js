/**
 * AutoForm Filler - Google Form Otomatik Doldurma JavaScript Kütüphanesi
 * Bu script WebView üzerinden Google Form'ları otomatik olarak doldurur.
 * 
 * Kullanım:
 * 1. Bu scripti WebView'a enjekte edin
 * 2. window.autofillGoogleForm() fonksiyonunu çağırın
 */

(function() {
    'use strict';
    
    // Form elementi seçicileri
    const SELECTORS = {
        TEXT_INPUT: 'input[type="text"], input[type="email"], input[type="number"], input[type="tel"], input[type="url"], textarea',
        RADIO: 'div[role="radio"]',
        CHECKBOX: 'div[role="checkbox"]',
        DROPDOWN: 'div[role="listbox"]',
        DROPDOWN_OPTION: 'div[role="option"]',
        SUBMIT_BUTTON: 'div[role="button"], button[type="submit"]',
        NEXT_BUTTON: 'div[jsname="M2UYVd"], button[type="button"]',
        GRID_ROW: 'div[role="radiogroup"]',
        DATE_INPUT: 'input[type="date"]',
        TIME_INPUT: 'input[type="time"]'
    };
    
    /**
     * Ana doldurma fonksiyonu
     */
    window.autofillGoogleForm = function() {
        console.log('[AutoFormFiller] Form doldurma başladı');
        
        try {
            // 1. Metin alanlarını doldur
            fillTextInputs();
            
            // 2. Radio button'ları seç
            selectRadioButtons();
            
            // 3. Checkbox'ları işaretle
            toggleCheckboxes();
            
            // 4. Dropdown'ları seç
            selectDropdownOptions();
            
            // 5. Grid sorularını doldur
            fillGridQuestions();
            
            // 6. Tarih/saat alanlarını doldur
            fillDateTimeFields();
            
            console.log('[AutoFormFiller] Form doldurma tamamlandı');
            return { success: true, message: 'Form başarıyla dolduruldu' };
            
        } catch (error) {
            console.error('[AutoFormFiller] Hata:', error);
            return { success: false, message: error.message };
        }
    };
    
    /**
     * Metin giriş alanlarını doldurur
     */
    function fillTextInputs() {
        const inputs = document.querySelectorAll(SELECTORS.TEXT_INPUT);
        console.log(`[AutoFormFiller] ${inputs.length} metin alanı bulundu`);
        
        inputs.forEach(function(input) {
            // Zaten doluysa atla
            if (input.value && input.value.trim() !== '') {
                console.log('[AutoFormFiller] Alan zaten dolu, atlanıyor');
                return;
            }
            
            const label = findLabelForInput(input);
            const value = getRandomValue(input.type, label);
            
            input.value = value;
            
            // React/Angular için event tetikle
            triggerInputEvents(input);
            
            console.log(`[AutoFormFiller] Metin alanı dolduruldu: ${label}`);
        });
    }
    
    /**
     * Radio button'ları rastgele seçer
     */
    function selectRadioButtons() {
        const radios = document.querySelectorAll(SELECTORS.RADIO);
        console.log(`[AutoFormFiller] ${radios.length} radio button bulundu`);
        
        if (radios.length === 0) return;
        
        // Radio button'ları gruplandır
        const groups = {};
        radios.forEach(function(radio) {
            const groupName = getRadioGroupName(radio);
            if (!groups[groupName]) {
                groups[groupName] = [];
            }
            groups[groupName].push(radio);
        });
        
        // Her gruptan birini rastgele seç
        Object.keys(groups).forEach(function(group) {
            const options = groups[group];
            if (options.length > 0) {
                const randomIndex = Math.floor(Math.random() * options.length);
                const selected = options[randomIndex];
                
                // Zaten seçili değilse tıkla
                if (!selected.classList.contains('isChecked')) {
                    selected.click();
                    console.log(`[AutoFormFiller] Radio seçildi: ${group}`);
                }
            }
        });
    }
    
    /**
     * Checkbox'ları rastgele işaretler
     */
    function toggleCheckboxes() {
        const checkboxes = document.querySelectorAll(SELECTORS.CHECKBOX);
        console.log(`[AutoFormFiller] ${checkboxes.length} checkbox bulundu`);
        
        checkboxes.forEach(function(checkbox) {
            // %70 olasılıkla işaretle
            if (Math.random() > 0.3 && !checkbox.classList.contains('isChecked')) {
                checkbox.click();
                console.log('[AutoFormFiller] Checkbox işaretlendi');
            }
        });
    }
    
    /**
     * Dropdown seçeneklerini rastgele seçer
     */
    function selectDropdownOptions() {
        const dropdowns = document.querySelectorAll(SELECTORS.DROPDOWN);
        console.log(`[AutoFormFiller] ${dropdowns.length} dropdown bulundu`);
        
        dropdowns.forEach(function(dropdown) {
            // Dropdown'u aç
            dropdown.click();
            
            // Seçeneklerin yüklenmesini bekle
            setTimeout(function() {
                const options = document.querySelectorAll(SELECTORS.DROPDOWN_OPTION);
                if (options.length > 0) {
                    const randomIndex = Math.floor(Math.random() * options.length);
                    options[randomIndex].click();
                    console.log(`[AutoFormFiller] Dropdown seçildi`);
                }
            }, 100);
        });
    }
    
    /**
     * Grid sorularını doldurur
     */
    function fillGridQuestions() {
        const gridRows = document.querySelectorAll(SELECTORS.GRID_ROW);
        console.log(`[AutoFormFiller] ${gridRows.length} grid satırı bulundu`);
        
        gridRows.forEach(function(row) {
            const radios = row.querySelectorAll(SELECTORS.RADIO);
            if (radios.length > 0) {
                const randomIndex = Math.floor(Math.random() * radios.length);
                radios[randomIndex].click();
            }
        });
    }
    
    /**
     * Tarih ve saat alanlarını doldurur
     */
    function fillDateTimeFields() {
        // Tarih alanları
        const dateInputs = document.querySelectorAll(SELECTORS.DATE_INPUT);
        dateInputs.forEach(function(input) {
            input.value = getRandomDate();
            triggerInputEvents(input);
        });
        
        // Saat alanları
        const timeInputs = document.querySelectorAll(SELECTORS.TIME_INPUT);
        timeInputs.forEach(function(input) {
            input.value = getRandomTime();
            triggerInputEvents(input);
        });
    }
    
    /**
     * Input için label bulur
     */
    function findLabelForInput(input) {
        // ID ile label ara
        if (input.id) {
            const labelByFor = document.querySelector('label[for="' + input.id + '"]');
            if (labelByFor) return labelByFor.textContent.trim();
        }
        
        // Parent'larda label ara
        let parent = input.parentElement;
        while (parent && parent.tagName !== 'FORM') {
            const label = parent.querySelector('label');
            if (label) return label.textContent.trim();
            parent = parent.parentElement;
        }
        
        // aria-label kullan
        return input.getAttribute('aria-label') || input.getAttribute('name') || '';
    }
    
    /**
     * Radio button grup adını alır
     */
    function getRadioGroupName(radio) {
        // aria-labelledby ile
        const labelledBy = radio.getAttribute('aria-labelledby');
        if (labelledBy) {
            const label = document.getElementById(labelledBy);
            if (label) return label.textContent.trim();
        }
        
        // Parent div'den grup adını al
        let parent = radio.parentElement;
        while (parent && parent !== document.body) {
            const heading = parent.querySelector('h1, h2, h3, h4, h5, h6, div[role="heading"]');
            if (heading) return heading.textContent.trim();
            parent = parent.parentElement;
        }
        
        return 'default_group_' + Math.random().toString(36).substr(2, 9);
    }
    
    /**
     * Alan tipine göre random değer üretir
     */
    function getRandomValue(inputType, label) {
        const normalizedLabel = (label || '').toLowerCase();
        const normalizedType = (inputType || '').toLowerCase();
        
        // Email kontrolü
        if (normalizedType.includes('email') || 
            normalizedLabel.includes('e-posta') || 
            normalizedLabel.includes('email') ||
            normalizedLabel.includes('mail')) {
            return generateRandomEmail();
        }
        
        // Telefon kontrolü
        if (normalizedType.includes('tel') || 
            normalizedLabel.includes('telefon') || 
            normalizedLabel.includes('phone')) {
            return generateRandomPhone();
        }
        
        // URL kontrolü
        if (normalizedType.includes('url') || 
            normalizedLabel.includes('website') || 
            normalizedLabel.includes('web site')) {
            return 'https://example.com';
        }
        
        // Sayı kontrolü
        if (normalizedType.includes('number') || 
            normalizedLabel.includes('sayı') || 
            normalizedLabel.includes('yaş') ||
            normalizedLabel.includes('numara')) {
            return (1..100).random().toString();
        }
        
        // Varsayılan: rastgele metin
        return generateRandomText();
    }
    
    /**
     * Random email üretir
     */
    function generateRandomEmail() {
        const names = ['ahmet', 'mehmet', 'ali', 'ayse', 'fatma', 'emre', 'sedan', 'murat'];
        const domains = ['gmail.com', 'hotmail.com', 'yahoo.com', 'outlook.com'];
        const name = names[Math.floor(Math.random() * names.length)];
        const domain = domains[Math.floor(Math.random() * domains.length)];
        const num = Math.floor(Math.random() * 999);
        return `${name}${num}@${domain}`;
    }
    
    /**
     * Random telefon numarası üretir
     */
    function generateRandomPhone() {
        const prefix = ['501', '502', '503', '504', '505'];
        const middle = Math.floor(Math.random() * 900) + 100;
        const end = Math.floor(Math.random() * 9000) + 1000;
        return `+90 ${prefix[Math.floor(Math.random() * prefix.length)]} ${middle} ${end}`;
    }
    
    /**
     * Random tarih üretir
     */
    function getRandomDate() {
        const day = Math.floor(Math.random() * 28) + 1;
        const month = Math.floor(Math.random() * 12) + 1;
        const year = Math.floor(Math.random() * 40) + 1980;
        return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
    
    /**
     * Random saat üretir
     */
    function getRandomTime() {
        const hour = Math.floor(Math.random() * 24);
        const minute = Math.floor(Math.random() * 60);
        return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    }
    
    /**
     * Random metin üretir
     */
    function generateRandomText() {
        const words = ['Lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit'];
        const wordCount = Math.floor(Math.random() * 5) + 3;
        let text = '';
        for (let i = 0; i < wordCount; i++) {
            text += words[Math.floor(Math.random() * words.length)] + ' ';
        }
        return text.trim().toLowerCase().replace(/^\w/, c => c.toUpperCase()) + '.';
    }
    
    /**
     * Input event'lerini tetikler (React/Angular için gerekli)
     */
    function triggerInputEvents(input) {
        const events = ['input', 'change', 'blur', 'focusout'];
        events.forEach(function(eventType) {
            const event = new Event(eventType, { bubbles: true });
            input.dispatchEvent(event);
        });
    }
    
    /**
     * Sonraki sayfa butonunu tıklar
     */
    window.goToNextPage = function() {
        const nextButtons = document.querySelectorAll(SELECTORS.NEXT_BUTTON);
        for (let btn of nextButtons) {
            const text = btn.textContent.toLowerCase();
            if (text.includes('next') || text.includes('ileri') || text.includes('sonraki')) {
                btn.click();
                return true;
            }
        }
        return false;
    };
    
    /**
     * Formu gönderir
     */
    window.submitForm = function() {
        const submitButtons = document.querySelectorAll(SELECTORS.SUBMIT_BUTTON);
        for (let btn of submitButtons) {
            const text = btn.textContent.toLowerCase();
            if (text.includes('submit') || text.includes('gönder') || text.includes('send') || text.includes('ilet')) {
                btn.click();
                return true;
            }
        }
        return false;
    };
    
    /**
     * Form bilgilerini döndürür
     */
    window.getFormInfo = function() {
        return {
            textInputs: document.querySelectorAll(SELECTORS.TEXT_INPUT).length,
            radios: document.querySelectorAll(SELECTORS.RADIO).length,
            checkboxes: document.querySelectorAll(SELECTORS.CHECKBOX).length,
            dropdowns: document.querySelectorAll(SELECTORS.DROPDOWN).length,
            hasSubmitButton: Array.from(document.querySelectorAll(SELECTORS.SUBMIT_BUTTON))
                .some(b => b.textContent.toLowerCase().includes('submit')),
            hasNextButton: Array.from(document.querySelectorAll(SELECTORS.NEXT_BUTTON))
                .some(b => b.textContent.toLowerCase().includes('next'))
        };
    };
    
    console.log('[AutoFormFiller] JavaScript kütüphanesi yüklendi');
    
})();
