package com.autofill.app.presentation.ui.form

/**
 * Form ekranı UI durumu.
 */
data class FormUiState(
    val isLoading: Boolean = false,
    val isFilling: Boolean = false,
    val isSubmitting: Boolean = false,
    val isSuccess: Boolean = false,
    val error: String? = null,
    val autoAdvance: Boolean = false,
    val hasNextButton: Boolean = false,
    val showSubmitButton: Boolean = false,
    val currentPage: Int = 0,
    val totalPages: Int = 0
)
