package com.autofill.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Uygulama başlangıç noktası.
 * Hilt dependency injection başlatılır.
 */
@HiltAndroidApp
class AutoFormFillerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Uygulama başlatıldığında yapılacak işlemler
    }
}
