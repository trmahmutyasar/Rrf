package com.autofill.app.presentation.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.autofill.app.data.generator.RandomDataGenerator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Ana ekran ViewModel'i.
 * Form URL'lerini yönetir ve son kullanılan formları saklar.
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val randomDataGenerator: RandomDataGenerator
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _recentForms = MutableStateFlow<List<String>>(emptyList())
    val recentForms: StateFlow<List<String>> = _recentForms.asStateFlow()

    init {
        // SharedPreferences veya veritabanından son formları yükle
        loadRecentForms()
    }

    /**
     * URL'i günceller.
     */
    fun updateUrl(url: String) {
        _uiState.update { it.copy(url = url, error = null) }
    }

    /**
     * URL'i panodan yapıştırır.
     */
    fun pasteFromClipboard(url: String) {
        if (url.isNotBlank()) {
            updateUrl(url)
        }
    }

    /**
     * Form yükleme işlemini başlatır.
     */
    fun loadForm(onFormLoaded: (String) -> Unit) {
        val currentUrl = _uiState.value.url.trim()
        
        if (currentUrl.isBlank()) {
            _uiState.update { it.copy(error = "Lütfen bir form linki girin") }
            return
        }
        
        if (!isValidGoogleFormUrl(currentUrl)) {
            _uiState.update { it.copy(error = "Geçersiz Google Form linki") }
            return
        }
        
        _uiState.update { it.copy(isLoading = true, error = null) }
        
        // Form URL'sini kaydet
        addToRecentForms(currentUrl)
        
        viewModelScope.launch {
            // Yükleme tamamlandığında callback çağır
            onFormLoaded(currentUrl)
            _uiState.update { it.copy(isLoading = false) }
        }
    }

    /**
     * URL'in geçerli bir Google Form olup olmadığını kontrol eder.
     */
    private fun isValidGoogleFormUrl(url: String): Boolean {
        val trimmedUrl = url.trim().lowercase()
        return trimmedUrl.contains("docs.google.com/forms") || 
               trimmedUrl.contains("forms.gle")
    }

    /**
     * Son kullanılan formları yükler.
     */
    private fun loadRecentForms() {
        // TODO: SharedPreferences veya Room database'den yükle
        // Şimdilik boş liste ile başla
        _recentForms.value = emptyList()
    }

    /**
     * Form URL'sini son kullanılanlara ekler.
     */
    private fun addToRecentForms(url: String) {
        val currentList = _recentForms.value.toMutableList()
        // Aynı URL varsa kaldır
        currentList.remove(url)
        // En başa ekle
        currentList.add(0, url)
        // Maksimum 10 form sakla
        val trimmedList = currentList.take(10)
        _recentForms.value = trimmedList
        
        // TODO: SharedPreferences veya Room database'e kaydet
    }

    /**
     * Son kullanılan formları temizler.
     */
    fun clearRecentForms() {
        _recentForms.value = emptyList()
        // TODO: SharedPreferences veya Room database'den temizle
    }

    /**
     * Hata mesajını temizler.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}

/**
 * Ana ekran UI durumu.
 */
data class HomeUiState(
    val url: String = "",
    val isLoading: Boolean = false,
    val error: String? = null
)
