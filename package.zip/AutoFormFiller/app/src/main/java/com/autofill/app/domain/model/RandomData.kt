package com.autofill.app.domain.model

/**
 * Random olarak üretilecek veri türlerini temsil eden model sınıfı.
 */
data class RandomData(
    val firstName: String = "",
    val lastName: String = "",
    val email: String = "",
    val phone: String = "",
    val address: String = "",
    val city: String = "",
    val country: String = "",
    val birthDate: String = "",
    val currentDate: String = "",
    const val text: String = "",
    val number: Int = 0,
    val yesNo: Boolean = true,
    val rating: Int = 0
) {
    companion object {
        // Türkiye'den rastgele isimler
        private val turkishFirstNames = listOf(
            "Ahmet", "Mehmet", "Ali", "Ayşe", "Fatma", "Emre", "Seda", "Murat",
            "Elif", "Deniz", "Kerem", "Zeynep", "Can", "Berna", "Oğuz", "Selin",
            "Burak", "Ezgi", "Ege", "İrem", "Kaan", "Buse", "Mert", "Naz",
            "Tolga", "Pınar", "Serkan", "Derya", "Gökhan", "Sibel", "Ümit", "Gül"
        )
        
        private val turkishLastNames = listOf(
            "Yılmaz", "Demir", "Çelik", "Şahin", "Arslan", "Çetin", "Kaya", "Öztürk",
            "Aydın", "Polat", "Aktaş", "Kara", "Koç", "Kurt", "Özdemir", "Aslan",
            "Bozkurt", "Gül", "Yıldız", "Erdoğan", "Şimşek", "Demirci", "Kara", "Arslan"
        )
        
        private val domains = listOf(
            "gmail.com", "hotmail.com", "yahoo.com", "outlook.com", "icloud.com"
        )
        
        private val cities = listOf(
            "İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Adana",
            "Gaziantep", "Konya", "Mersin", "Eskişehir", "Kayseri", "Samsun"
        )
        
        private val countries = listOf(
            "Türkiye", "United States", "Germany", "France", "United Kingdom",
            "Italy", "Spain", "Canada", "Australia", "Japan"
        )
        
        private val streets = listOf(
            "Atatürk Cad.", "Cumhuriyet Bulvarı", "Meclis Mah.", "Merkez Sokak",
            "Bağdat Cad.", "Eskişehir Yolu", "Ankara Cad.", "İstanbul Cad."
        )
        
        private val neighborhoods = listOf(
            "Merkez", "Yeni Mahalle", "Çayırlı", "Fatih", "Atatürk", "Şeker",
            "Gülbahçe", "Hürriyet", "Zafer", "Çiğdem", "Begonya, Kardelen"
        )
        
        // Random veri üreticileri
        private fun randomFromList(list: List<String>): String = list.random()
        
        private fun randomNumber(min: Int, max: Int): Int = 
            (min..max).random()
        
        private fun randomDigit(): String = (0..9).random().toString()
        
        private fun generatePhoneNumber(): String {
            return when (randomNumber(0, 3)) {
                0 -> "+90 5${randomDigit()}${randomDigit()} ${randomDigit()}${randomDigit()} ${randomDigit()}${randomDigit()} ${randomDigit()}${randomDigit()}"
                1 -> "+90 53${randomNumber(1, 9)}${randomNumber(0, 9)} ${randomNumber(10, 99)} ${randomNumber(10, 99)} ${randomNumber(10, 99)}"
                2 -> "+90 54${randomNumber(1, 9)}${randomNumber(0, 9)} ${randomNumber(10, 99)} ${randomNumber(10, 99)} ${randomNumber(10, 99)}"
                else -> "+90 5${randomNumber(1, 9)}${randomNumber(0, 9)} ${randomNumber(10, 99)} ${randomNumber(10, 99)} ${randomNumber(10, 99)}"
            }
        }
        
        private fun generateRandomText(wordCount: Int = 5): String {
            val words = listOf(
                "Lorem", "ipsum", "dolor", "sit", "amet", "consectetur",
                "adipiscing", "elit", "sed", "do", "eiusmod", "tempor",
                "incididunt", "ut", "labore", "et", "dolore", "magna",
                "aliqua", "Ut", "enim", "ad", "minim", "veniam", "quis",
                "nostrud", "exercitation", "ullamco", "laboris", "nisi",
                "ut", "aliquip", "ex", "ea", "commodo", "consequat"
            )
            return (1..wordCount).map { randomFromList(words) }.joinToString(" ").lowercase()
                .replaceFirstChar { it.uppercase() } + "."
        }
        
        private fun generateEmail(firstName: String, lastName: String): String {
            val domain = randomFromList(domains)
            val suffix = randomNumber(1, 999)
            return "${firstName.lowercase()}.${lastName.lowercase()}$suffix@$domain"
        }
        
        private fun generateAddress(): String {
            val streetNum = randomNumber(1, 199)
            val buildingNum = randomNumber(1, 50)
            return "${randomFromList(streets)} No:$streetNum, ${randomFromList(neighborhoodes)} Mah., Kat:$buildingNum"
        }
        
        private fun generateBirthDate(): String {
            val day = randomNumber(1, 28)
            val month = randomNumber(1, 12)
            val year = randomNumber(1960, 2005)
            return String.format("%02d/%02d/%04d", day, month, year)
        }
        
        private fun generateCurrentDate(): String {
            val day = randomNumber(1, 28)
            val month = randomNumber(1, 12)
            val year = 2024 + randomNumber(0, 2)
            return String.format("%02d/%02d/%04d", day, month, year)
        }
        
        /**
         * Yeni bir RandomData örneği oluşturur.
         * Tüm alanlar rastgele değerlerle doldurulur.
         */
        fun generate(): RandomData {
            val firstName = randomFromList(turkishFirstNames)
            val lastName = randomFromList(turkishLastNames)
            
            return RandomData(
                firstName = firstName,
                lastName = lastName,
                email = generateEmail(firstName, lastName),
                phone = generatePhoneNumber(),
                address = generateAddress(),
                city = randomFromList(cities),
                country = randomFromList(countries),
                birthDate = generateBirthDate(),
                currentDate = generateCurrentDate(),
                text = generateRandomText((3..10).random()),
                number = randomNumber(1, 100),
                yesNo = listOf(true, false).random(),
                rating = randomNumber(1, 5)
            )
        }
        
        /**
         * Belirli bir tür için random değer döndürür.
         */
        fun getValueForType(dataType: DataType): String {
            val data = generate()
            return when (dataType) {
                DataType.FIRST_NAME -> data.firstName
                DataType.LAST_NAME -> data.lastName
                DataType.FULL_NAME -> "${data.firstName} ${data.lastName}"
                DataType.EMAIL -> data.email
                DataType.PHONE -> data.phone
                DataType.ADDRESS -> data.address
                DataType.CITY -> data.city
                DataType.COUNTRY -> data.country
                DataType.BIRTH_DATE -> data.birthDate
                DataType.CURRENT_DATE -> data.currentDate
                DataType.TEXT -> data.text
                DataType.NUMBER -> data.number.toString()
                DataType.YES_NO -> if (data.yesNo) "Evet" else "Hayır"
                DataType.RATING -> data.rating.toString()
                DataType.RANDOM_WORDS -> generateRandomText((2..8).random())
            }
        }
    }
}

/**
 * Form alanları için desteklenen veri türleri.
 */
enum class DataType {
    FIRST_NAME,
    LAST_NAME,
    FULL_NAME,
    EMAIL,
    PHONE,
    ADDRESS,
    CITY,
    COUNTRY,
    BIRTH_DATE,
    CURRENT_DATE,
    TEXT,
    NUMBER,
    YES_NO,
    RATING,
    RANDOM_WORDS
}
