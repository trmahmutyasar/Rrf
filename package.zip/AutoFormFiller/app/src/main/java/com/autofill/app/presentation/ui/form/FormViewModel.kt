package com.autofill.app.presentation.ui.form

import android.webkit.WebView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.autofill.app.data.generator.RandomDataGenerator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject
import javax.inject.Inject

/**
 * Form ekranı ViewModel'i.
 * WebView'da form doldurma işlemlerini yönetir.
 */
@HiltViewModel
class FormViewModel @Inject constructor(
    private val randomDataGenerator: RandomDataGenerator
) : ViewModel() {

    private val _uiState = MutableStateFlow(FormUiState())
    val uiState: StateFlow<FormUiState> = _uiState.asStateFlow()

    private var currentFormUrl: String = ""

    /**
     * Form URL'sini ayarlar.
     */
    fun setUrl(url: String) {
        currentFormUrl = url
        _uiState.update { it.copy(isLoading = true) }
    }

    /**
     * Otomatik sayfa ilerleme ayarını değiştirir.
     */
    fun setAutoAdvance(enabled: Boolean) {
        _uiState.update { it.copy(autoAdvance = enabled) }
    }

    /**
     * Sayfa bilgilerini alır ve durumu günceller.
     */
    fun onPageInfoReceived(jsonInfo: String) {
        try {
            val info = JSONObject(jsonInfo)
            val hasNextButton = info.optBoolean("hasNextButton", false)
            val hasSubmitButton = info.optBoolean("hasSubmitButton", false)
            val radioCount = info.optInt("radioCount", 0)
            val textInputCount = info.optInt("textInputCount", 0)
            
            _uiState.update { state ->
                state.copy(
                    isLoading = false,
                    hasNextButton = hasNextButton,
                    showSubmitButton = hasSubmitButton || !hasNextButton,
                    currentPage = if (hasSubmitButton) state.totalPages else state.currentPage + 1,
                    totalPages = if (hasSubmitButton) state.currentPage + 1 else state.totalPages
                )
            }
        } catch (e: Exception) {
            _uiState.update { it.copy(isLoading = false) }
        }
    }

    /**
     * Formu otomatik olarak doldurur.
     */
    fun fillForm(webView: WebView) {
        if (_uiState.value.isFilling) return
        
        viewModelScope.launch {
            _uiState.update { it.copy(isFilling = true, error = null) }
            
            // JavaScript injection ile formu doldur
            val fillScript = generateFillScript()
            
            webView.evaluateJavascript(fillScript) { result ->
                viewModelScope.launch {
                    delay(500) // Animasyon için bekle
                    
                    if (_uiState.value.autoAdvance && _uiState.value.hasNextButton) {
                        // Sonraki sayfaya geç
                        delay(300)
                        clickNextButton(webView)
                    } else {
                        _uiState.update { it.copy(isFilling = false) }
                    }
                }
            }
        }
    }

    /**
     * Formu gönderir.
     */
    fun submitForm(webView: WebView) {
        if (_uiState.value.isSubmitting) return
        
        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true, error = null) }
            
            // Submit butonunu bul ve tıkla
            val submitScript = """
                (function() {
                    var submitButtons = document.querySelectorAll('div[role="button"], button[type="submit"]');
                    for (var btn of submitButtons) {
                        var text = btn.textContent.toLowerCase();
                        if (text.includes('submit') || text.includes('gönder') || text.includes('send') || text.includes('ilet')) {
                            btn.click();
                            return true;
                        }
                    }
                    return false;
                })();
            """.trimIndent()
            
            webView.evaluateJavascript(submitScript) { result ->
                if (result == "true") {
                    viewModelScope.launch {
                        delay(2000) // Form gönderilmesi için bekle
                        _uiState.update { 
                            it.copy(
                                isSubmitting = false,
                                isSuccess = true
                            ) 
                        }
                    }
                } else {
                    _uiState.update { 
                        it.copy(
                            isSubmitting = false,
                            error = "Gönder butonu bulunamadı"
                        ) 
                    }
                }
            }
        }
    }

    /**
     * Sonraki sayfa butonunu tıklar.
     */
    private fun clickNextButton(webView: WebView) {
        val nextScript = """
            (function() {
                var nextButtons = document.querySelectorAll('div[jsname="M2UYVd"], div[role="button"], button[type="button"]');
                for (var btn of nextButtons) {
                    var text = btn.textContent.toLowerCase();
                    if (text.includes('next') || text.includes('ileri') || text.includes('sonraki') || text.includes('devam')) {
                        btn.click();
                        return true;
                    }
                }
                return false;
            })();
        """.trimIndent()
        
        webView.evaluateJavascript(nextScript) { result ->
            _uiState.update { it.copy(isFilling = false) }
            if (result != "true") {
                // Sonraki buton bulunamadıysa form submit olabilir
                _uiState.update { it.copy(showSubmitButton = true) }
            }
        }
    }

    /**
     * Form doldurma JavaScript kodunu üretir.
     */
    private fun generateFillScript(): String {
        return """
            (function() {
                console.log('AutoFormFiller: Form doldurma başladı');
                
                // 1. Text input'ları doldur
                var textInputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="number"], input[type="tel"], textarea');
                textInputs.forEach(function(input) {
                    var label = findLabelForInput(input);
                    var value = window.AndroidInterface.getRandomValue(input.type, label || '');
                    input.value = value;
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                    console.log('Filled text input: ' + label);
                });
                
                // 2. Radio button'ları seç
                var radioGroups = {};
                var radios = document.querySelectorAll('div[role="radio"]');
                radios.forEach(function(radio) {
                    var groupName = radio.getAttribute('aria-labelledby') || 'default';
                    if (!radioGroups[groupName]) {
                        radioGroups[groupName] = [];
                    }
                    radioGroups[groupName].push(radio);
                });
                
                Object.keys(radioGroups).forEach(function(group) {
                    var options = radioGroups[group];
                    if (options.length > 0) {
                        var randomIndex = Math.floor(Math.random() * options.length);
                        options[randomIndex].click();
                        console.log('Selected radio: ' + group);
                    }
                });
                
                // 3. Checkbox'ları işaretle (rastgele)
                var checkboxes = document.querySelectorAll('div[role="checkbox"]');
                checkboxes.forEach(function(checkbox) {
                    if (Math.random() > 0.3) { // %70 olasılıkla işaretle
                        checkbox.click();
                    }
                });
                
                // 4. Dropdown'ları seç
                var dropdowns = document.querySelectorAll('div[role="listbox"]');
                dropdowns.forEach(function(dropdown) {
                    dropdown.click();
                    setTimeout(function() {
                        var options = document.querySelectorAll('div[role="option"]');
                        if (options.length > 0) {
                            var randomOption = options[Math.floor(Math.random() * options.length)];
                            randomOption.click();
                        }
                    }, 100);
                });
                
                console.log('AutoFormFiller: Form doldurma tamamlandı');
                return 'success';
            })();
            
            // Input için label bulan yardımcı fonksiyon
            function findLabelForInput(input) {
                var id = input.id;
                if (id) {
                    var label = document.querySelector('label[for="' + id + '"]');
                    if (label) return label.textContent;
                }
                
                var parent = input.parentElement;
                while (parent && parent.tagName !== 'FORM') {
                    var label = parent.querySelector('label');
                    if (label) return label.textContent;
                    parent = parent.parentElement;
                }
                
                return '';
            }
        """.trimIndent()
    }

    /**
     * Hata mesajını temizler.
     */
    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    /**
     * Başarı durumunu sıfırlar.
     */
    fun resetSuccess() {
        _uiState.update { it.copy(isSuccess = false) }
    }
}

/**
 * Form ekranı UI durumu.
 */
data class FormUiState(
    val isLoading: Boolean = false,
    val isFilling: Boolean = false,
    val isSubmitting: Boolean = false,
    val isSuccess: Boolean = false,
    val error: String? = null,
    val autoAdvance: Boolean = false,
    val hasNextButton: Boolean = false,
    val showSubmitButton: Boolean = false,
    val currentPage: Int = 0,
    val totalPages: Int = 0
)
