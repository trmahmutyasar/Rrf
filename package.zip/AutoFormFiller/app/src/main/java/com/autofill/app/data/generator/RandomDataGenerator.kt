package com.autofill.app.data.generator

import com.autofill.app.domain.model.DataType
import com.autofill.app.domain.model.RandomData
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

/**
 * Random veri üretici servisi.
 * Data katmanında yer alır ve form alanları için random değerler üretir.
 */
@Singleton
class RandomDataGenerator @Inject constructor() {

    // Türkçe isim listesi
    private val firstNames = listOf(
        "Ahmet", "Mehmet", "Ali", "Ayşe", "Fatma", "Emre", "Seda", "Murat",
        "Elif", "Deniz", "Kerem", "Zeynep", "Can", "Berna", "Oğuz", "Selin",
        "Burak", "Ezgi", "Ege", "İrem", "Kaan", "Buse", "Mert", "Naz",
        "Tolga", "Pınar", "Serkan", "Derya", "Gökhan", "Sibel", "Ümit", "Gül",
        "Hakan", "Nermin", "Furkan", "Yasemin", "Sinan", "Dilan", "Berk", "Cansu"
    )

    private val lastNames = listOf(
        "Yılmaz", "Demir", "Çelik", "Şahin", "Arslan", "Çetin", "Kaya", "Öztürk",
        "Aydın", "Polat", "Aktaş", "Kara", "Koç", "Kurt", "Özdemir", "Aslan",
        "Bozkurt", "Gül", "Yıldız", "Erdoğan", "Şimşek", "Demirci", "Kara", "Arslan",
        "Eroğlu", "Duman", "Köse", "Kaplan", "Çakır", "Özkan", "Mutlu", "Sever"
    )

    private val emailDomains = listOf(
        "gmail.com", "hotmail.com", "yahoo.com", "outlook.com", "icloud.com",
        "yandex.com", "protonmail.com", "mail.com"
    )

    private val cities = listOf(
        "İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Adana",
        "Gaziantep", "Konya", "Mersin", "Eskişehir", "Kayseri", "Samsun",
        "Trabzon", "Erzurum", "Diyarbakır", "Şanlıurfa", "Malatya", "Kahramanmaraş"
    )

    private val countries = listOf(
        "Türkiye", "United States", "Germany", "France", "United Kingdom",
        "Italy", "Spain", "Canada", "Australia", "Japan", "China", "Russia",
        "Netherlands", "Belgium", "Austria", "Switzerland"
    )

    private val streets = listOf(
        "Atatürk Caddesi", "Cumhuriyet Bulvarı", "Meclis Mahallesi", "Merkez Sokak",
        "Bağdat Caddesi", "Eskişehir Yolu", "Ankara Caddesi", "İstanbul Caddesi",
        "Milli Egemenlik Caddesi", "Gençlik Caddesi", "Barış Caddesi", "Özgürlük Caddesi"
    )

    private val neighborhoods = listOf(
        "Merkez", "Yeni Mahalle", "Çayırlı", "Fatih", "Atatürk", "Şeker",
        "Gülbahçe", "Hürriyet", "Zafer", "Çiğdem", "Begonya", "Kardelen",
        "Ferah", "Sevgi", "Umut", "Saygı", "Dostluk", "Barış"
    )

    private val loremWords = listOf(
        "Lorem", "ipsum", "dolor", "sit", "amet", "consectetur", "adipiscing",
        "elit", "sed", "do", "eiusmod", "tempor", "incididunt", "ut", "labore",
        "et", "dolore", "magna", "aliqua", "Ut", "enim", "ad", "minim", "veniam",
        "quis", "nostrud", "exercitation", "ullamco", "laboris", "nisi", "ut",
        "aliquip", "ex", "ea", "commodo", "consequat", "Duis", "aute", "irure",
        "dolor", "in", "reprehenderit", "in", "voluptate", "velit", "esse",
        "cillum", "dolore", "eu", "fugiat", "nulla", "pariatur", "Excepteur",
        "sint", "occaecat", "cupidatat", "non", "proident", "sunt", "in", "culpa",
        "qui", "officia", "deserunt", "mollit", "anim", "id", "est", "laborum"
    )

    /**
     * Rastgele bir isim döndürür.
     */
    fun getRandomName(): String {
        return "${firstNames.random()} ${lastNames.random()}"
    }

    /**
     * Rastgele bir isim (sadece ad) döndürür.
     */
    fun getRandomFirstName(): String = firstNames.random()

    /**
     * Rastgele bir soyisim döndürür.
     */
    fun getRandomLastName(): String = lastNames.random()

    /**
     * Rastgele bir email adresi döndürür.
     */
    fun getRandomEmail(): String {
        val name = firstNames.random().lowercase()
        val surname = lastNames.random().lowercase()
        val number = (1..999).random()
        val domain = emailDomains.random()
        return "$name.$surname$number@$domain"
    }

    /**
     * Rastgele bir telefon numarası döndürür.
     */
    fun getRandomPhone(): String {
        val prefix = listOf("501", "502", "503", "504", "505", "506", "507", "508", "509", "550", "551", "552")
        val middle = (100..999).random()
        val end = (1000..9999).random()
        return "+90 ${prefix.random()} $middle $end"
    }

    /**
     * Rastgele bir adres döndürür.
     */
    fun getRandomAddress(): String {
        val street = streets.random()
        val number = (1..199).random()
        val neighborhood = neighborhoods.random()
        val floor = (1..15).random()
        val door = (1..50).random()
        return "$street No:$number, $neighborhood Mah., Kat:$floor, Kapı No:$door"
    }

    /**
     * Rastgele bir şehir döndürür.
     */
    fun getRandomCity(): String = cities.random()

    /**
     * Rastgele bir ülke döndürür.
     */
    fun getRandomCountry(): String = countries.random()

    /**
     * Rastgele bir tarih döndürür.
     */
    fun getRandomDate(startYear: Int = 1960, endYear: Int = 2005): String {
        val day = (1..28).random()
        val month = (1..12).random()
        val year = (startYear..endYear).random()
        return String.format("%02d.%02d.%04d", day, month, year)
    }

    /**
     * Rastgele bir sayı döndürür.
     */
    fun getRandomNumber(min: Int = 1, max: Int = 100): String {
        return (min..max).random().toString()
    }

    /**
     * Rastgele bir metin döndürür.
     */
    fun getRandomText(wordCount: Int = 5): String {
        val words = (1..wordCount).map { loremWords.random() }
        val text = words.joinToString(" ").lowercase()
        return text.replaceFirstChar { it.uppercase() } + "."
    }

    /**
     * Rastgele bir uzun metin döndürür.
     */
    fun getRandomLongText(sentenceCount: Int = 3): String {
        val sentences = (1..sentenceCount).map { getRandomText((5..10).random()) }
        return sentences.joinToString(" ")
    }

    /**
     * Rastgele bir derecelendirme döndürür (1-5 arası).
     */
    fun getRandomRating(): String = (1..5).random().toString()

    /**
     * Evet/Hayır değeri döndürür.
     */
    fun getRandomYesNo(): String = if (Random.nextBoolean()) "Evet" else "Hayır"

    /**
     * Form alanının tipine göre uygun random değeri döndürür.
     */
    fun getValueForFieldType(fieldType: String, fieldLabel: String = ""): String {
        val normalizedType = fieldType.lowercase()
        val normalizedLabel = fieldLabel.lowercase()

        return when {
            // Email alanları
            normalizedType.contains("email") ||
            normalizedLabel.contains("e-posta") ||
            normalizedLabel.contains("email") ||
            normalizedLabel.contains("mail") -> getRandomEmail()

            // Telefon alanları
            normalizedType.contains("tel") ||
            normalizedLabel.contains("telefon") ||
            normalizedLabel.contains("phone") ||
            normalizedLabel.contains("gsm") ||
            normalizedLabel.contains("cep") -> getRandomPhone()

            // Tarih alanları
            normalizedType.contains("date") ||
            normalizedLabel.contains("tarih") ||
            normalizedLabel.contains("doğum") ||
            normalizedLabel.contains("dogum") ||
            normalizedLabel.contains("birth") -> getRandomDate()

            // Sayı alanları
            normalizedType.contains("number") ||
            normalizedType.contains("range") ||
            normalizedLabel.contains("sayı") ||
            normalizedLabel.contains("sayi") ||
            normalizedLabel.contains("numara") ||
            normalizedLabel.contains("miktar") ||
            normalizedLabel.contains("yaş") ||
            normalizedLabel.contains("yas") ||
            normalizedLabel.contains("yaş") ||
            normalizedLabel.contains("quantity") ||
            normalizedLabel.contains("adet") -> getRandomNumber()

            // Adres alanları
            normalizedLabel.contains("adres") ||
            normalizedLabel.contains("adress") ||
            normalizedLabel.contains("address") ||
            normalizedLabel.contains("mahalle") ||
            normalizedLabel.contains("sokak") -> getRandomAddress()

            // Şehir alanları
            normalizedLabel.contains("şehir") ||
            normalizedLabel.contains("sehir") ||
            normalizedLabel.contains("city") ||
            normalizedLabel.contains("il") -> getRandomCity()

            // Ülke alanları
            normalizedLabel.contains("ülke") ||
            normalizedLabel.contains("ulke") ||
            normalizedLabel.contains("country") ||
            normalizedLabel.contains("ülke") -> getRandomCountry()

            // İsim alanları
            normalizedLabel.contains("adınız") ||
            normalizedLabel.contains("adiniz") ||
            normalizedLabel.contains("first name") ||
            normalizedLabel.contains("firstname") ||
            normalizedLabel.contains("name") -> getRandomName()

            // Soyisim alanları
            normalizedLabel.contains("soyad") ||
            normalizedLabel.contains("surname") ||
            normalizedLabel.contains("last name") ||
            normalizedLabel.contains("lastname") -> getRandomLastName()

            // Derecelendirme alanları
            normalizedLabel.contains("derece") ||
            normalizedLabel.contains("rating") ||
            normalizedLabel.contains("puan") ||
            normalizedLabel.contains("beğen") ||
            normalizedLabel.contains("memnun") ||
            normalizedLabel.contains("satisfaction") ||
            normalizedType.contains("range") -> getRandomRating()

            // Uzun metin alanları
            normalizedType.contains("textarea") ||
            normalizedType.contains("paragraph") ||
            normalizedLabel.contains("açıklama") ||
            normalizedLabel.contains("yorum") ||
            normalizedLabel.contains("not") ||
            normalizedLabel.contains("description") ||
            normalizedLabel.contains("comment") ||
            normalizedLabel.contains("message") -> getRandomLongText((3..6).random())

            // Varsayılan: kısa metin
            else -> getRandomText((3..8).random())
        }
    }

    /**
     * Tüm random verileri içeren bir nesne döndürür.
     */
    fun generateAllData(): RandomData {
        val firstName = firstNames.random()
        val lastName = lastNames.random()
        
        return RandomData(
            firstName = firstName,
            lastName = lastName,
            email = getRandomEmail(),
            phone = getRandomPhone(),
            address = getRandomAddress(),
            city = getRandomCity(),
            country = getRandomCountry(),
            birthDate = getRandomDate(),
            currentDate = getRandomDate(2023, 2025),
            text = getRandomText(),
            number = (1..100).random(),
            yesNo = Random.nextBoolean(),
            rating = (1..5).random()
        )
    }
}
