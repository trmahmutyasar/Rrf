package com.autofill.app.domain.usecase

import com.autofill.app.domain.model.DataType
import com.autofill.app.domain.model.RandomData
import javax.inject.Inject

/**
 * Random veri üretme use case'i.
 * Domain katmanında yer alır ve business logic'i temsil eder.
 */
class GenerateRandomDataUseCase @Inject constructor() {

    /**
     * Form alanının tipine göre uygun random değeri döndürür.
     * 
     * @param fieldType Alan tipi (text, email, number, vs.)
     * @param fieldLabel Alan etiketi (ipucu için)
     * @return Üretilen random değer
     */
    fun execute(fieldType: String = "text", fieldLabel: String = ""): String {
        val normalizedType = fieldType.lowercase()
        
        // Etikete göre veri türünü tahmin et
        val inferredType = inferDataType(normalizedType, fieldLabel)
        
        return RandomData.getValueForType(inferredType)
    }
    
    /**
     * Tamamen random bir isim-çifti üretir.
     */
    fun generateFullName(): String = RandomData.getValueForType(DataType.FULL_NAME)
    
    /**
     * Tamamen random bir email üretir.
     */
    fun generateEmail(): String = RandomData.getValueForType(DataType.EMAIL)
    
    /**
     * Tamamen random bir telefon numarası üretir.
     */
    fun generatePhone(): String = RandomData.getValueForType(DataType.PHONE)
    
    /**
     * Tamamen random bir adres üretir.
     */
    fun generateAddress(): String = RandomData.getValueForType(DataType.ADDRESS)
    
    /**
     * Tamamen random bir tarih üretir.
     */
    fun generateDate(): String = RandomData.getValueForType(DataType.CURRENT_DATE)
    
    /**
     * Tamamen random bir metin üretir.
     */
    fun generateText(): String = RandomData.getValueForType(DataType.TEXT)
    
    /**
     * Tamamen random bir sayı üretir.
     */
    fun generateNumber(): String = RandomData.getValueForType(DataType.NUMBER)
    
    /**
     * Tamamen random bir derecelendirme üretir.
     */
    fun generateRating(): String = RandomData.getValueForType(DataType.RATING)
    
    /**
     * Veri türünü tahmin eder.
     * Form alanının type özelliği ve label'ına göre uygun türü belirler.
     */
    private fun inferDataType(type: String, label: String): DataType {
        val normalizedLabel = label.lowercase()
        
        // Email kontrolü
        if (type.contains("email") || 
            normalizedLabel.contains("e-posta") || 
            normalizedLabel.contains("email") ||
            normalizedLabel.contains("mail")) {
            return DataType.EMAIL
        }
        
        // Telefon kontrolü
        if (type.contains("tel") || 
            normalizedLabel.contains("telefon") || 
            normalizedLabel.contains("phone") ||
            normalizedLabel.contains("gsm") ||
            normalizedLabel.contains("cep")) {
            return DataType.PHONE
        }
        
        // Tarih kontrolü
        if (type.contains("date") || 
            normalizedLabel.contains("tarih") || 
            normalizedLabel.contains("date") ||
            normalizedLabel.contains("doğum") ||
            normalizedLabel.contains("dogum") ||
            normalizedLabel.contains("birth")) {
            return DataType.CURRENT_DATE
        }
        
        // Sayı kontrolü
        if (type.contains("number") || 
            type.contains("range") ||
            normalizedLabel.contains("sayı") || 
            normalizedLabel.contains("sayi") ||
            normalizedLabel.contains("numara") ||
            normalizedLabel.contains("miktar") ||
            normalizedLabel.contains("yaş") ||
            normalizedLabel.contains("yas") ||
            normalizedLabel.contains("age") ||
            normalizedLabel.contains("quantity")) {
            return DataType.NUMBER
        }
        
        // Adres kontrolü
        if (normalizedLabel.contains("adres") || 
            normalizedLabel.contains("adress") ||
            normalizedLabel.contains("address") ||
            normalizedLabel.contains("mahalle") ||
            normalizedLabel.contains("sokak")) {
            return DataType.ADDRESS
        }
        
        // Şehir kontrolü
        if (normalizedLabel.contains("şehir") || 
            normalizedLabel.contains("sehir") ||
            normalizedLabel.contains("city") ||
            normalizedLabel.contains("il")) {
            return DataType.CITY
        }
        
        // Ülke kontrolü
        if (normalizedLabel.contains("ülke") || 
            normalizedLabel.contains("ulke") ||
            normalizedLabel.contains("country")) {
            return DataType.COUNTRY
        }
        
        // İsim kontrolü
        if (normalizedLabel.contains("adınız") || 
            normalizedLabel.contains("adiniz") ||
            normalizedLabel.contains("first name") ||
            normalizedLabel.contains("firstname") ||
            normalizedLabel.contains("name")) {
            return DataType.FULL_NAME
        }
        
        // Soyisim kontrolü
        if (normalizedLabel.contains("soyad") || 
            normalizedLabel.contains("surname") ||
            normalizedLabel.contains("last name") ||
            normalizedLabel.contains("lastname")) {
            return DataType.LAST_NAME
        }
        
        // Derecelendirme kontrolü
        if (normalizedLabel.contains("derece") || 
            normalizedLabel.contains("rating") ||
            normalizedLabel.contains("puan") ||
            normalizedLabel.contains("beğen") ||
            normalizedLabel.contains("memnun") ||
            normalizedLabel.contains("satisfaction") ||
            type.contains("range")) {
            return DataType.RATING
        }
        
        // Varsayılan: metin
        return DataType.TEXT
    }
}
