package com.autofill.app.presentation.ui.form

import android.annotation.SuppressLint
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.delay

/**
 * Form ekranı Composable bileşeni.
 * WebView üzerinde Google Form'u gösterir ve otomatik doldurma işlemini gerçekleştirir.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormScreen(
    formUrl: String,
    onBack: () -> Unit,
    viewModel: FormViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var showSettings by remember { mutableStateOf(false) }

    LaunchedEffect(formUrl) {
        viewModel.setUrl(formUrl)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Form",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (uiState.currentPage > 0 && uiState.totalPages > 0) {
                            Text(
                                text = "Sayfa ${uiState.currentPage} / ${uiState.totalPages}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { webViewRef?.reload() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Yenile")
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Ayarlar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        },
        floatingActionButton = {
            if (!uiState.isSubmitting) {
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Otomatik sayfa ilerleme anahtarı
                    if (uiState.totalPages > 1) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Otomatik İlerle",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Switch(
                                checked = uiState.autoAdvance,
                                onCheckedChange = { viewModel.setAutoAdvance(it) }
                            )
                        }
                    }
                    
                    // Ana doldurma butonu
                    ExtendedFloatingActionButton(
                        onClick = {
                            webViewRef?.let { webView ->
                                viewModel.fillForm(webView)
                            }
                        },
                        icon = {
                            if (uiState.isFilling) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    contentDescription = null
                                )
                            }
                        },
                        text = {
                            Text(
                                text = if (uiState.isSubmitting) "Gönderiliyor..." 
                                       else if (uiState.isFilling) "Dolduruluyor..." 
                                       else "Doldur"
                            )
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        expanded = uiState.isFilling || uiState.isSubmitting
                    )
                    
                    // Gönder butonu
                    if (uiState.showSubmitButton) {
                        FloatingActionButton(
                            onClick = {
                                webViewRef?.let { webView ->
                                    viewModel.submitForm(webView)
                                }
                            },
                            containerColor = MaterialTheme.colorScheme.tertiary
                        ) {
                            Icon(
                                Icons.Default.Send,
                                contentDescription = "Gönder"
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // WebView
            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        webViewRef = this
                        configureWebView(this)
                        // Random data generator'a erişim için JavaScript interface
                        addJavascriptInterface(
                            RandomDataJSInterface(viewModel),
                            "AndroidInterface"
                        )
                        loadUrl(formUrl)
                    }
                },
                update = { webView ->
                    if (webView.url != formUrl) {
                        webView.loadUrl(formUrl)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            
            // Yükleme göstergesi
            if (uiState.isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator()
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(text = "Form yükleniyor...")
                        }
                    }
                }
            }
            
            // Hata mesajı
            uiState.error?.let { error ->
                Snackbar(
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.BottomCenter),
                    action = {
                        TextButton(onClick = { viewModel.clearError() }) {
                            Text("Kapat")
                        }
                    }
                ) {
                    Text(error)
                }
            }
            
            // Başarı mesajı
            if (uiState.isSuccess) {
                Snackbar(
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.BottomCenter),
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Form başarıyla dolduruldu ve gönderildi!")
                    }
                }
            }
        }
    }
    
    // Ayarlar dialog'u
    if (showSettings) {
        SettingsDialog(
            autoAdvance = uiState.autoAdvance,
            onAutoAdvanceChange = { viewModel.setAutoAdvance(it) },
            onDismiss = { showSettings = false }
        )
    }
}

/**
 * WebView yapılandırması.
 */
@SuppressLint("SetJavaScriptEnabled")
private fun configureWebView(webView: WebView) {
    webView.apply {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
        }
        
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Sayfa yüklendikten sonra form elementlerini analiz et
                view?.evaluateJavascript(
                    """
                    (function() {
                        var radios = document.querySelectorAll('div[role="radio"]');
                        var checkboxes = document.querySelectorAll('div[role="checkbox"]');
                        var textInputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="number"], textarea');
                        var dropdowns = document.querySelectorAll('div[role="listbox"]');
                        var submitButtons = document.querySelectorAll('div[role="button"], button[type="submit"]');
                        var nextButtons = document.querySelectorAll('div[jsname="M2UYVd"], button[type="button"]');
                        
                        var info = {
                            radioCount: radios.length,
                            checkboxCount: checkboxes.length,
                            textInputCount: textInputs.length,
                            dropdownCount: dropdowns.length,
                            submitButtonCount: submitButtons.length,
                            nextButtonCount: nextButtons.length,
                            hasSubmitButton: Array.from(submitButtons).some(b => 
                                b.textContent.toLowerCase().includes('submit') || 
                                b.textContent.toLowerCase().includes('gönder') ||
                                b.textContent.toLowerCase().includes('send')
                            ),
                            hasNextButton: Array.from(nextButtons).some(b =>
                                b.textContent.toLowerCase().includes('next') ||
                                b.textContent.toLowerCase().includes('ileri') ||
                                b.textContent.toLowerCase().includes('sonraki')
                            )
                        };
                        
                        // Sayfa bilgilerini logla
                        console.log('Form Info:', JSON.stringify(info));
                        
                        // Android interface'e bilgi gönder
                        if (window.AndroidInterface) {
                            window.AndroidInterface.onPageLoaded(JSON.stringify(info));
                        }
                        
                        return JSON.stringify(info);
                    })();
                    """.trimIndent(),
                    null
                )
            }
        }
    }
}

/**
 * JavaScript'ten Kotlin tarafına veri göndermek için interface.
 */
class RandomDataJSInterface(
    private val viewModel: FormViewModel
) {
    @JavascriptInterface
    fun onPageLoaded(jsonInfo: String) {
        // Sayfa bilgilerini işle
        viewModel.onPageInfoReceived(jsonInfo)
    }
    
    @JavascriptInterface
    fun log(message: String) {
        // JavaScript loglarını işle
        android.util.Log.d("AutoFormFiller", "JS: $message")
    }
}

/**
 * Ayarlar dialog'u.
 */
@Composable
private fun SettingsDialog(
    autoAdvance: Boolean,
    onAutoAdvanceChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ayarlar") },
        text = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Otomatik Sayfa İlerleme",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            text = "Her sayfa doldurulduktan sonra otomatik sonraki sayfaya geç",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = autoAdvance,
                        onCheckedChange = onAutoAdvanceChange
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Kapat")
            }
        }
    )
}
