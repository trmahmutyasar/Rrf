package com.autofill.app.presentation.ui.home

/**
 * Ana ekran UI durumu.
 */
data class HomeUiState(
    val url: String = "",
    val isLoading: Boolean = false,
    val error: String? = null
)
