package com.autofill.app.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.autofill.app.presentation.ui.form.FormScreen
import com.autofill.app.presentation.ui.home.HomeScreen

/**
 * Uygulama navigasyon yöneticisi.
 * Ekranlar arası geçişleri yönetir.
 */
@Composable
fun AppNavigation(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        // Ana ekran
        composable(route = Screen.Home.route) {
            HomeScreen(
                onFormLoaded = { url ->
                    // Form URL'sini encode ederek form ekranına geç
                    val encodedUrl = java.net.URLEncoder.encode(url, "UTF-8")
                    navController.navigate(Screen.Form.createRoute(encodedUrl))
                }
            )
        }
        
        // Form ekranı
        composable(
            route = Screen.Form.route,
            arguments = listOf(
                navArgument("formUrl") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val encodedUrl = backStackEntry.arguments?.getString("formUrl") ?: ""
            val formUrl = java.net.URLDecoder.decode(encodedUrl, "UTF-8")
            
            FormScreen(
                formUrl = formUrl,
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}

/**
 * Ekran tanımları.
 */
sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Form : Screen("form/{formUrl}") {
        fun createRoute(formUrl: String): String = "form/$formUrl"
    }
}
