package com.autofill.app.di

import com.autofill.app.data.generator.RandomDataGenerator
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Dependency Injection modülü.
 * Uygulama genelinde kullanılacak bağımlılıkları sağlar.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /**
     * RandomDataGenerator singleton olarak sağlanır.
     * Uygulama boyunca aynı instance kullanılır.
     */
    @Provides
    @Singleton
    fun provideRandomDataGenerator(): RandomDataGenerator {
        return RandomDataGenerator()
    }
}
