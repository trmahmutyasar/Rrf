# AutoForm Filler

Google Form'ları otomatik olarak dolduran Android uygulaması.

## Özellikler

- 🎯 **Tek Tıkla Doldurma**: Google Form linkini yapıştırın, uygulama otomatik olarak tüm alanları doldursun
- 🔄 **Çoklu Sayfa Desteği**: Birden fazla sayfadan oluşan formları destekler
- 📝 **Her Türlü Alan**: Metin, email, telefon, tarih, sayı, çoktan seçmeli, checkbox, dropdown ve daha fazlası
- 🎲 **Tamamen Random**: Tüm bilgiler rastgele üretilir
- 🌙 **Modern UI**: Material Design 3 ile modern ve kullanışlı arayüz
- 📱 **Android Uyumlu**: Android 7.0 (API 24) ve üzeri sürümlerle uyumlu

## Desteklenen Form Elementleri

Uygulama aşağıdaki form elementlerini otomatik olarak doldurabilir:

- **Metin Alanları**: Kısa metin, paragraf, email, telefon, URL
- **Sayısal Alanlar**: Sayı girişleri, derecelendirme (1-5)
- **Seçim Alanları**: Radio button'lar, checkbox'lar, dropdown listeler
- **Tarih/Saat**: Tarih ve saat seçiciler
- **Grid Sorular**: Matris formatındaki sorular
- **Dosya Yükleme**: Zorunlu olmayan alanlar atlanır

## Kurulum

### Gereksinimler

- Android Studio Hedgehog (2023.1.1) veya üzeri
- JDK 17
- Android SDK 34
- Gradle 8.5

### Adımlar

1. **Projeyi Klonla**
   ```bash
   git clone https://github.com/kullaniciadi/AutoFormFiller.git
   cd AutoFormFiller
   ```

2. **Android Studio'da Aç**
   - Android Studio'yu açın
   - "Open" seçeneği ile proje klasörünü seçin
   - Gradle sync işleminin tamamlanmasını bekleyin

3. **Projeyi Derle**
   - Build > Make Project seçeneğini kullanın
   - Veya terminalden: `./gradlew assembleDebug`

4. **Cihazda Çalıştır**
   - Bir Android cihaz bağlayın veya emulator başlatın
   - Run > Run 'app' seçeneğini kullanın

## Kullanım

1. Uygulamayı açın
2. Google Form linkini yapıştırın veya panodan yapıştırın
3. "Formu Yükle ve Doldur" butonuna tıklayın
4. Form yüklendikten sonra "Doldur" butonuna basın
5. Uygulama tüm alanları rastgele verilerle dolduracaktır
6. Formu göndermek için "Gönder" butonuna basın

### Ayarlar

- **Otomatik Sayfa İlerleme**: Çok sayfalı formlarda her sayfa doldurulduktan sonra otomatik sonraki sayfaya geçer
- **Manuel Doldurma**: Her sayfayı manuel olarak doldurabilirsiniz

## Mimari

Uygulama **Clean Architecture** prensiplerine uygun olarak geliştirilmiştir:

```
com.autofill.app/
├── data/
│   └── generator/
│       └── RandomDataGenerator.kt    # Random veri üretimi
├── domain/
│   ├── model/
│   │   └── RandomData.kt             # Veri modelleri
│   └── usecase/
│       └── GenerateRandomDataUseCase.kt  # Business logic
├── presentation/
│   ├── ui/
│   │   ├── home/                     # Ana ekran
│   │   └── form/                     # Form ekranı
│   └── navigation/                   # Navigasyon
├── di/
│   └── AppModule.kt                  # Dependency Injection
└── MainActivity.kt                   # Giriş noktası
```

## Teknolojiler

- **Kotlin**: Programlama dili
- **Jetpack Compose**: Modern UI toolkit
- **Material Design 3**: Tasarım sistemi
- **Hilt**: Dependency Injection
- **Coroutines**: Asenkron programlama
- **WebView + JavaScript Injection**: Form doldurma mekanizması

## Test

Projeyi test etmek için:

```bash
./gradlew test
```

## Lisans

Bu proje MIT Lisansı altında lisanslanmıştır.

## Katkıda Bulunma

1. Fork'layın
2. Feature branch oluşturun (`git checkout -b feature/yeni-ozellik`)
3. Commit'lerinizi yapın (`git commit -am 'Yeni özellik eklendi'`)
4. Branch'inizi push'layın (`git push origin feature/yeni-ozellik`)
5. Pull Request oluşturun

## İletişim

Sorularınız için: destek@autofillapp.com
